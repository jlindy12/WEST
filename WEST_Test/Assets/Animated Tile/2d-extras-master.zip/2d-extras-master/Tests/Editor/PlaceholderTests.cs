using NUnit.Framework;

public class U2DExtrasPlaceholder 
{
    [Test]
    public void PlaceHolderTest()
    {
        Assert.Pass("2D Extras tests are in a separate package.");
    }
}
